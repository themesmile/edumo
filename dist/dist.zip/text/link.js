const link = {
  starter: {
    home: '/'
  }
}

export default link
